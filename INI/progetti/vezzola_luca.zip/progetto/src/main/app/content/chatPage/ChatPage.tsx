function ChatPage() {
  return <p>This is the chat page</p>;
}

export default ChatPage;
