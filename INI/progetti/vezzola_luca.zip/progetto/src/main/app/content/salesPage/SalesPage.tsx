function SalesPage() {
  return <p>This is the sales page</p>;
}

export default SalesPage;
