function ShopPage() {
  return <p>This is the shop page</p>;
}

export default ShopPage;
