function UserPage() {
  return <p>This is the user page</p>;
}

export default UserPage;
